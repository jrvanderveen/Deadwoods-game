package deadwoodsgui;

import java.util.InputMismatchException;
import java.util.Scanner;
import processing.core.*;


/**
 *
 * @author vander64
 */
public class Deadwoods extends PApplet{ 
   private static String myText = "Enter num Players(2-8): ";  
   static int numPlayers;
   static Board board;
   private static String[] args = {"boardFrame"};

   public void setup() {
      textAlign(CENTER, CENTER);
      textSize(30);
      fill(0); 
      frame.setLocation(0,0);
   }
    public void settings(){
        size(500, 100);
    }

    public void draw() {
        frame.setLocation(0,0);
        background(255);
        text(myText, 0, 0, width, height);
    }

    public void keyPressed() {
        int numplayer= 0;
        int credits=0;
        int numdays=4;
        int dollars=0;
        int rank=1;
        Dice dice= new Dice();

      if (keyCode == BACKSPACE) {
        if ((myText.length())> 24) {
          myText = myText.substring(0, myText.length()-1);
        }
      } else if (keyCode == DELETE) {
        myText = "Enter num Players: ";
      } else if (keyCode != SHIFT && keyCode != CONTROL && keyCode != ALT && keyCode != ENTER) {
        myText = myText + key;
      }
      else if(keyCode == ENTER){
          if(myText.length() > 24){
            numPlayers = Integer.parseInt(myText.substring(24, myText.length()));
            if(numPlayers<=8 && numPlayers>=2){
                Player[] players=new Player[numPlayers];
                String name = "";
                for(int i=0;i<numPlayers;i++){
                    name = Integer.toString(i);
                    players[i]=new Player(rank,dollars,credits,name,dice);
                }
                switch(numPlayers){
                    case 2:
                    case 3:
                        numdays=3;
                        break;				
                    case 5:				  
                        credits=2;
                        break;
                    case 6:					 
                        credits=4;
                        break;
                    case 7:
                    case 8:
                        rank=2;
                        break;
                }
                board = new Board(numdays,players,dice);
                PApplet.runSketch(args, board);
                board.createRooms();
                board.createTrailer();
                board.createOffice();
                board.startGame();
            }
          }
      }
    }
}


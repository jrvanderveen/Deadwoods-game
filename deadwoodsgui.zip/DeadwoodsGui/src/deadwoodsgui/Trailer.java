/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deadwoodsgui;

import java.util.*;
import processing.core.*;

public class Trailer extends PApplet{

   private ArrayList<String> adjRooms = new ArrayList<String>();
   
   //constructor 
   public Trailer(ArrayList<String> adjRooms){
      this.adjRooms = adjRooms;
   }
   public ArrayList<String> getAdjacentRooms(){
       return this.adjRooms;
   }
   
}

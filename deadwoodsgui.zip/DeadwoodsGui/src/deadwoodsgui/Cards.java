/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deadwoodsgui;
import processing.core.*;

public class Cards extends PApplet{
    private String card_info;
    private String scene;
    private int budget;
    private String[] array;
    private String[] rolesArray;
    
    public Cards(String card_info){
        this.array = card_info.split("///");       
        this.scene = array[0];
        this.rolesArray=new String[array.length-2];
        this.budget = Integer.parseInt(array[1]);
        int j=0;
        for(int i=2;i<array.length;i++){
            this.rolesArray[j] = array[i];
            j++;
        }
        
        
    }
    
    
    
    public String getScene(){
        return this.scene;
    }
    public int getBudget(){
        return this.budget;
    }
    public String[] getRolesArray(){
        return this.rolesArray;
    }
    
}